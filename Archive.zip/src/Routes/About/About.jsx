import './Style.css'

function About() {
  return (
    <div>
      I am About
    </div>
  );
}

export default About;