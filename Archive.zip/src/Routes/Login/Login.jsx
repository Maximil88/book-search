import './Style.css'

function Login() {
  return (
    <div>
      I am Login
    </div>
  );
}

export default Login;