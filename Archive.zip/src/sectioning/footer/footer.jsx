import './style.css';

function Footer() {
  return (
    <footer>
    Footer
    </footer>
  );
}

export default Footer;